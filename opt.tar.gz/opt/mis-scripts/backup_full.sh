#!/bin/bash

# Variables
DESTINO="/mnt/backup_dir" # Directorio destino fijo para todos los backups
FECHA=$(date +%Y%m%d)

# Mostrar ayuda si se pasa la opción -h o los argumentos son incorrectos
if [[ "$1" == "-h" || $# -ne 1 ]]; then
	echo "Uso: $0 <directorio_a_respaldar>"
	echo "Este script realiza un backup en $DESTINO del directorio indicado"
	echo "Ejemplo: $0 /var/log"
	exit 1
fi

# Directorio a respaldar
ORIGEN=$1

# Validar que el directorio a respaldar existe
if [[ ! -d "$ORIGEN" ]]; then
	echo "Error: El directorio origen $ORIGEN no existe."
	echo "Para ayuda, ejecuta: $0 -h"
	exit 1
fi

# Validdar que el directorio destino existe
if [[ ! -d "$DESTINO" ]]; then
	echo "Error: El directorio destino $DESTINO no existe. Asegúrate de que esté montado"
	exit 1
fi

# Crear el backup
NOMBRE_BACKUP=$(basename "$ORIGEN")_bkp_$FECHA.tar.gz
tar -czf "$DESTINO/$NOMBRE_BACKUP" "$ORIGEN"

# Verificar si el backup fue exitoso
if [[ $? -eq 0 ]]; then
	echo "Backup completado: $DESTINO/$NOMBRE_BACKUP"
else
	echo "Error al crear el backup."
	exit 1
fi
